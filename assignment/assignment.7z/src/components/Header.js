
const Header = ({libraryName, location}) => {
  return (
    <div className="bg-primary text-white p-3">
      <h2>City Central Library</h2>
      <p>456 Library Rd, Booktown</p>
    </div>
  );
};

export default Header;
