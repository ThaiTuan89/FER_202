const Footer = () => (
    <div className="bg-dark text-white text-center p-3 mt-4">
      <p>Phone: 0833-48-2255</p>
    </div>
  );
  export default Footer;
  